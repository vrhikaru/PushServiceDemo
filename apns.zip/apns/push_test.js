var apn = require('apn');
 
var options = {
  token: {
    key: "AuthKey_3BD57H3Z38_pushDemo.p8",
    keyId: "3BD57H3Z38",
    teamId: "4FYSWHP746"
  },
  production: false
};
 
var apnProvider = new apn.Provider(options);
var note = new apn.Notification();
let deviceToken = "f3d370344ec63cfeace689460f070002b52b7e24a4692db602e51f3bea04e23c"
note.alert = "Wendy, I love you";
note.sound = "default";
note.badge = 1;
note.topic = "maudowan.PushServiceDemo";

apnProvider.send(note, deviceToken).then( (result) => {
  // see documentation for an explanation of result
});